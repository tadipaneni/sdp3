package com.example.newsdp3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Newsdp3Application {

	public static void main(String[] args) {
		SpringApplication.run(Newsdp3Application.class, args);
	}

}
